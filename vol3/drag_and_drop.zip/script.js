/*tutorials i used:
"https://www.kirupa.com/html5/drag.htm" + comment section
"https://www.kirupa.com/html5/handling_events_for_many_elements.htm"
TODO: look at magnet.js & interact.js snapping grids
TODO also look into: https://stackoverflow.com/questions/2973407/javascript-jquery-how-to-do-snapping-drag-and-drop
*/

//stores the div containing the draggable item
let container = document.getElementById("mainDiv");
//current div is saved here
let activeItem = null;

//false when unused; set to true while in use
let active = false;

// event listeners
//event listeners are attached to container, not dragItem!! if it would be attached to dragItem we would stop dragging the item when the mouse leaves it
container.addEventListener("mousedown", dragStart, false);
container.addEventListener("mousemove", drag, false);
container.addEventListener("mouseup", dragEnd, false);
//event listeners for touch
container.addEventListener("touchstart", dragStart, false);
container.addEventListener("touchmove", drag, false);
container.addEventListener("touchend", dragEnd, false);


//3 functions for dragging:
//sets initial coordinates
function dragStart(e) {

    if (e.target !== e.currentTarget) {
        active = true;

        //item we interact with
        activeItem = e.target;

        //checks if activeItem actually exists
        if (activeItem !== null) {
            //if activeItem.xOffset doesnt exist set to 0
            if(!activeItem.xOffset) {
                activeItem.xOffset = 0;
            }
            //if activeItem.yOffset doesnt exist set to 0
            if(!activeItem.yOffset) {
                activeItem.yOffset = 0;
            }
            //sets initial Position; needs different parameters for touch/mouse use
            if (e.type === "touchstart") {
                //for touch use only
                activeItem.initialX = e.touches[0].clientX - activeItem.xOffset;
                activeItem.initialY = e.touches[0].clientY - activeItem.yOffset;
            } else {
                //for mouse use only
                activeItem.initialX = e.clientX - activeItem.xOffset;
                activeItem.initialY = e.clientY - activeItem.yOffset;
            }
        }
    }
}

//sets current coordinates
function drag(e) {
    //checks for variable set in startDrag function
    if (active) {

        e.preventDefault();

        //sets current position; again, different parameters for touch/mouse use
        if (e.type === "touchmove") {
            //for touch use only
            activeItem.currentX = e.touches[0].clientX - activeItem.initialX;
            activeItem.currentY = e.touches[0].clientY - activeItem.initialY;
        } else {
            //for mouse use only
            activeItem.currentX = e.clientX - activeItem.initialX;
            activeItem.currentY = e.clientY - activeItem.initialY;
        }

        //sets xOffset & yOffset to current Position; this makes sure the next time we start dragging we start were we left off
        activeItem.xOffset = activeItem.currentX;
        activeItem.yOffset = activeItem.currentY;

        //calls function setTranslate
        setTranslate(activeItem.currentX, activeItem.currentY, activeItem);
    }
}

//sets the new position for our dragged item; this function actually moves the item (changes position in CSS)
function setTranslate(xPos, yPos, el) {
    el.style.transform = "translate3d(" + xPos + "px, " + yPos + "px, 0)";
}

//sets "finished position" as new initial position
function dragEnd(e) {
    //checks if activeItem actually exists
    if (activeItem !== null) {
        activeItem.initialX = activeItem.currentX;
        activeItem.initialY = activeItem.currentY;
    }

    //sets dragging to no longer be active
    active = false;
    activeItem = null;
}